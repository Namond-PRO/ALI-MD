---------

### <br>  ❖ ALI MD V1 ❖
🔰 **`THE WORLD BEST WHATSAPP BOT CREATED BY ALI🐍`** 🔰

----------

<a><img src='https://cdn.ironman.my.id/i/2du3i5.jpg'/></a>

-------

 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=00008B&center=true&vCenter=true&multiline=false&lines=`ALI+-+MD+-+V1+WHATSAPP+BOT`" alt="">

<br>

-----------
<div align="center"><br> <img src="https://profile-counter.glitch.me/ALI-MD-V1/count.svg" /><br>ALI-MD-V1</div>

------------

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

[![FORK ALI_MD-V4](https://img.shields.io/badge/FORK%20-ALI%20MD%20V1-white)](https://github.com/itx-alii-raza/ALI-MD-V1/fork)

### <br>    ❖ SESSION_ID ❖


`✠ IF YOU DON'T HAVE YOUR SESSION_ID SO U CAN GET IT CLICK ON SESSION_ID BUTTON AND PASTE YOUR NUMBER With COUNTRY CODE EXAMPLE:+92300xxxxxx THEN YOU CAN GET YOUR SESSION_ID ✠`

----------
1. USE SESSION 1.
<p align="center">
<a href="https://ali-md.onrender.com"><img height= "35" title="Author" src="https://img.shields.io/badge/GET SESSION ID:1-black?style=for-the-badge&logo=render"></a>
<p/>
2. USE SESSION 2 IF SESSION:1 DOESN'T WORK.
<p align="center">
<a href="https://ali-md-web-a1116a65685a.herokuapp.com/"><img height= "35" title="Author" src="https://img.shields.io/badge/GET SESSION ID:2-black?style=for-the-badge&logo=render"></a>
<p/>
---------------

### <br>   ❖ DEPLOY_HEROKU ❖

`✠ IF YOU WANT TO DEPLOY ALI MD V1 BOT ON HEROKU SO FIRST GET YOUR SESSION_ID THEN CLICK THIS BLUE BUTTON [DEPLOY TO HEROKU] THEN YOU CAN ENJOY THIS BOT ✠`

------------
 
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new-app?template=https://github.com/itx-alii-raza/ALI-MD)

🥂 `THIS BOT IS CREATED TO DOWNLOAD'S AND FIND VARIOUS TYPES THINGS QUICKLY **EXAMPLE** LOGO, PHOTO, STICKERS, VIDEOS, MOVIES, ADULT, AND MANY MORE FEATURES BY USING THIS BOT™ THIS BOT IS CREATED TO USING` 🥂 **[Baileys](https://github.com/WhiskeySockets/Baileys)**

------------------

### <br> ❖ FOR SUPPORT ❖

**`➩ HII DEARS FRIENDS IF YOU WANT ANY HELP SO YOU CAN CONTACT↘︎ WITH ME WIA WHATSAPP ITS ME ALI࿐➺`**

-------

<p align="center">
  <a href="https://wa.me/+923003588997?text=*ʜɪɪ+ᴀʟɪ+ɪ+ɴᴇᴇᴅ+ʜᴇʟᴘ!.+ɪ+ᴍᴇssᴀɢᴇᴅ+ʏᴏᴜ+ғʀᴏᴍ+ᴀʟɪ-ᴍᴅ-ᴠ1+ʀᴇᴘᴏ!!*" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/ Whatsapp -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

-----------    

`✠ IF YOU WANT MORE ABOUT ALI MD V1 WHATSAPP BOT :-NEW UPDATED NEW CMDS SO JOIN OUR WHATSAPP CHANNEL FOR MORE INFORMATION CLICK THIS RED BUTTON 🔳 AND JOIN THE GROUP ✠`

---------

<a href="https://whatsapp.com/channel/0029VaoRxGmJpe8lgCqT1T2h"><img src="https://img.shields.io/badge/%F0%9F%8E%89%20ᴊᴏɪɴ%20ᴏᴜʀ%20ᴡʜᴀᴛsᴀᴘᴘ%20ᴄʜᴀɴɴᴇʟ-red" alt="🔰 ᴊᴏɪɴ ᴍʏ ᴡʜᴀᴛsᴀᴘᴘ ᴄʜᴀɴɴᴇʟ ғᴏʀ ᴜᴘᴅᴀᴛᴇ 🔰" width="300"></a>

--------------
 

### <br>    ❖ DEPLOY_TALKDROVE ❖

  1. Deploy Now. 

<a href='https://host.talkdrove.com/dashboard/select-bot/prepare-deployment?botId=51' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY-NOW-h?color=navy&style=for-the-badge&logo=visualstudiocode'/></a></p>

----------

### <br>    ❖ DEPLOY_REPLIT ❖

`✠ IF U HAVE YOUR REPLIT ACCOUNT SO YOU CAN EASY DEPLOY ALI MD V4 ON REPLIT CLICK BLACK BUTTON [DEPLOY TO REPLIT] AND FIND CONFIG.JSON FILE THEN PASTE YOUR SESSION AND MONGODB KEY THEN RUN CODE AND ENJOY BOT ✠`

-------------

<p align="left"><a href="https://repl.it/github/Kgtech-cmr/KERM-MD-V1"> <img src='https://img.shields.io/badge/-REPLIT-orange?style=for-the-badge&logo=replit&logoColor=white'/></a>

--------------

### <br>   ❖ DEPLOY_KOYEB ❖

`✠ IF YOU HAVE YOUR KOYEB ACCOUNT SO YOU CAN DEPLOY ALI MD V1 ON KOYEB WITH EASY SETUP NOTE:-MAYBE SOME PROBLEM TO DEPLOY ON KOYEB I ILL FIX SOON ✠`

---------

